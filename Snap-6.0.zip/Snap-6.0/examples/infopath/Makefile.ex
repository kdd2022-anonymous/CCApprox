#
#	configuration variables for the example

## Main application file
MAIN = infopath
DEPH = $(EXSNAPADV)/cascdynetinf.h
DEPCPP = $(EXSNAPADV)/cascdynetinf.cpp

