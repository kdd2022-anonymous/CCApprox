#
#	configuration variables for the example

## Main application file
MAIN = kronfit
DEPH = $(EXSNAPADV)/kronecker.h
DEPCPP = $(EXSNAPADV)/kronecker.cpp

