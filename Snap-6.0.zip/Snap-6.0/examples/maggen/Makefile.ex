#
#	configuration variables for the example

## Main application file
MAIN = maggen
DEPH = $(EXSNAPADV)/mag.h
DEPCPP = $(EXSNAPADV)/mag.cpp

