#
#	configuration variables for the example

## Main application file
MAIN = netinf
DEPH = $(EXSNAPADV)/cascnetinf.h
DEPCPP = $(EXSNAPADV)/cascnetinf.cpp

